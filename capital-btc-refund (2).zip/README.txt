# Capital BTC Refund — Professional Website

## 🚀 How to Put Online (GitHub Pages)

1. Go to [https://github.com](https://github.com) and log in.
2. Click **New Repository** → name it `capital-btc-refund` → click **Create Repository**.
3. Click **Upload files** and drag all files from this ZIP.
4. Click **Commit changes** (green button).
5. Go to **Settings → Pages → Source → Deploy from a branch**.
6. Choose **Branch:** `main` and **Folder:** `/ (root)` → click **Save`.
7. Wait 1–2 minutes, then open your link:  
   👉 `https://yourusername.github.io/capital-btc-refund/`

**Contact Info:**  
📧 refundbtc5@gmail.com  
📞 +1 343 353 6317 (WhatsApp / IMO / SMS)
